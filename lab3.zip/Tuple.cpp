#include "Tuple.h"

vector<string> Tuple::getValues(){
    return values;
}

void Tuple::setValues(vector<string> values) {
    Tuple::values = values;
}
